package testCases;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;


import io.github.bonigarcia.wdm.WebDriverManager;
import pages.CurrencyConvertPage;

public class CurrencyConvert {
	public static void main(String[] args) throws InterruptedException {
    
		ChromeOptions option = new ChromeOptions();
		WebDriverManager.chromedriver().setup();
		WebDriver driver = new ChromeDriver(option);
		driver.get("https://www.paysera.lt/v2/en-LT/fees/currency-conversion-calculator#/");
		
		CurrencyConvertPage convertPage = new CurrencyConvertPage(driver);
		Thread.sleep(7000);

		System.out.println( "Display Calculating profit/loss value is:"+convertPage.displayValue());
		Thread.sleep(4000);
		
		convertPage.actualProfit();
		Thread.sleep(4000);
            //Enter Sell Amount                                                                                                                                                                                                                            
		convertPage.sellAmountEnter("100");
		
		Thread.sleep(3000);
		System.out.println("Enter sell amount");
		//buy File is empty
	    convertPage.buyFillsIsEmpty();
		
		Thread.sleep(3000);
		//Enter buy Amount
		convertPage.buyAmountEnter("100");
		 System.out.println("Enter buy amount");
		
		//sell File is empty
		convertPage.sellFillsIsEmpty();
		Thread.sleep(5000);
		// Close browser instance
		driver.quit();
	}

}