package pages;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class CurrencyConvertPage {

	WebDriver driver;
	// Constructor that will be automatically called as soon as the object of the
	// class is created
	public CurrencyConvertPage(WebDriver driver) {
		this.driver = driver;
	}

	By pseraAmount = By.xpath("//*[@id=\"currency-exchange-app\"]/div/div/div[2]/table/tbody/tr[1]/td[4]/span/span/span");
	By bankAmount1 = By.xpath("//*[@id=\"currency-exchange-app\"]/div/div/div[2]/table/tbody/tr[1]/td[5]/span/span/span[1]");
	By lossAmont = By.xpath("//*[@id=\"currency-exchange-app\"]/div/div/div[2]/table/tbody/tr[1]/td[5]/span/span/span[2]");
	By sellFills = By.xpath("//*[@id=\"currency-exchange-app\"]/div/div/div[2]/div[1]/form/div[1]/input");
	By buyFills = By.xpath("//*[@id=\"currency-exchange-app\"]/div/div/div[2]/div[1]/form/div[3]/input");
	
	public String displayValue() {
		String lossAmount = driver.findElement(lossAmont).getText();
		return lossAmount;
	}
	public void actualProfit() {
		double psAmount = Double.parseDouble(driver.findElement(pseraAmount).getText());
		double bankAmount = Double.parseDouble(driver.findElement(bankAmount1).getText());
		String lossAmount = driver.findElement(lossAmont).getText();

		if (psAmount > 0) {
			double actualP1 = bankAmount - psAmount;
			System.out.println("Actual Calculating profit/loss value is:" + String.format("%.2f", actualP1));
			 try {
			 Assert.assertEquals(lossAmount, "("+String.format("%.2f", actualP1)+")");
			System.out.println("Actual Calculating profit/loss value and display value is Equal!");
			 }catch(AssertionError e) {
			 System.out.println("Actual Calculating profit/loss value and display value is Not Equal!");
			 }
		} else {
			System.out.println("No rate");
		}
	}
	public void sellAmountEnter(String amount) {
		driver.findElement(sellFills).clear();
		driver.findElement(sellFills).sendKeys(amount);
	}
	public void buyFillsIsEmpty() {
		String buyFills1 = driver.findElement(buyFills).getText();
		if (buyFills1.isBlank()) {
			System.out.println("Buy Fills is Empty!");
		}
	}
	public void buyAmountEnter(String amount) {
		driver.findElement(buyFills).sendKeys(amount);
	}
	public void sellFillsIsEmpty() {
		String sellFills1 = driver.findElement(sellFills).getText();
		if (sellFills1.isBlank()) {
			System.out.println("Sell Fills is Empty!");
		}
	}
}